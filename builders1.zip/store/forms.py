from django import forms
from store.models import *


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
	    'name',
        'category',
        'description',
        'price',
        'image',
        'availibility',
        'country_name',
        'street_name',
        'district_name',
        'ward_name',
        'phoneNo',

        ]







