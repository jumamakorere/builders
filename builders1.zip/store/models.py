from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User
from django.conf import settings
from autoslug import AutoSlugField
from ckeditor.fields import RichTextField
from django_countries.fields import CountryField
from phonenumber_field.modelfields import PhoneNumberField

# Create your models here.

STATUS = (
    ('draft', 'Draft'),
    ('publish', 'Publish'),
    
)


class Category(models.Model):
    name = models.CharField(("Category name"),max_length=50, null=False, blank=False)
    # image = models.ImageField(upload_to='media/categories/%Y/%m/%d/', blank=True,null=True)
    slug = models.SlugField(unique=True, max_length=100, db_index=True)
    class Meta:
        ordering = ('name',)
        verbose_name = 'category'
        verbose_name_plural = 'categories'
    def get_absolute_path(self):
        return reverse('store:product_list') + f'?category={self.id}'
    def __str__(self):
        return self.name


class Product(models.Model):
    user = models.ForeignKey(User,related_name='products', on_delete=models.CASCADE, default=1)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products')
    name = models.CharField(("Product name"),max_length=100, null=False, blank=False)
    slug = AutoSlugField(populate_from='name',unique=True, null=True,default=None)
    description = RichTextField()
    price = models.FloatField(("Product price"),null=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    image = models.ImageField(("Product image"),upload_to='media/products/%Y/%m/%d/', blank=True)
    availibility = models.BooleanField(null=False, default=True)
    street_name = models.CharField(max_length=200,blank=False, null=False)
    district_name = models.CharField(max_length=200,blank=False, null=False)
    ward_name = models.CharField(max_length=200,blank=False, null=False)
    country_name = CountryField(blank_label='(select country)',blank=False, null=False)
    phoneNo=PhoneNumberField(("Phone Number"),null=False, blank=False)
    phoneNo.error_messages['invalid'] = 'Incorrect International Calling Code or Mobile Number! correct by format: +255 XXX XXX XXX XXXX',
    is_approval = models.BooleanField(default=False)
    class Meta:
        index_together = ('id', 'slug')
        ordering = ('-created',)
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('store:product_details', kwargs={'slug': self.slug})



