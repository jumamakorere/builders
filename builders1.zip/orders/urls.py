from django.urls import path
from orders import views
from .views import editorders,editUser

app_name = 'orders'
urlpatterns = [
    path('place', views.CreateOrder.as_view(), name='place'),
    path('my', views.MyOrders.as_view(), name='my'),
    path('adminpageorders/<int:pk>/', views.adminpageorders, name='adminpageorders'),
    path('details/<int:pk>/', views.OrderDetails.as_view(), name='details'),
    path('invoice/<int:pk>/', views.OrderInvoice.as_view(), name='invoice'),
    path('allusers/', views.allusers, name='allusers'),
    path('allorders/', views.allorders, name='allorders'),
    path('allproducts/', views.allproducts, name='allproducts'),
    path('Buy and Sell/', views.buyandsell, name='buyandsell'),
    path('Update Order/<pk>', editorders.as_view(), name='editorders'),
    path('Edit  your edit User/<pk>', editUser.as_view(), name='editUser'),
    path('Delete this User?/<pk>', views.remouser, name='remouser'),
  
]
