from orders.models import Order
from django import forms





class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['address', 'city', 'street_name','district_name','ward_name','country_name','phoneNo',]

