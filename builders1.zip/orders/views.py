from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, render, redirect, Http404
from django.views import generic
from orders.forms import OrderForm
from orders.models import  Order, OrderItem
from cart.cart import Cart
from django.db.models import Count
from store.models import Product
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count
from django.views.generic import UpdateView
from django.urls import reverse_lazy
# Create your views here.


class CreateOrder(LoginRequiredMixin, generic.CreateView):
    form_class = OrderForm
    template_name = 'orders/place_order.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cart = Cart(self.request)
        products = Product.objects.filter(pk__in=cart.cart.keys())
        cart_items = map(
            lambda p: {'product': p, 'quantity': cart.cart[str(p.id)]['quantity'], 'total': p.price*cart.cart[str(p.id)]['quantity']}, products)
        context['summary'] = cart_items
        return context

    def form_valid(self, form):
        cart = Cart(self.request)
        if len(cart) == 0:
            return redirect('cart:cart_details')
        order = form.save(commit=False)
        order.user = self.request.user
        order.total_price = cart.get_total_price()
        order.save()
        products = Product.objects.filter(id__in=cart.cart.keys())
        orderitems = []
        for i in products:
            q = cart.cart[str(i.id)]['quantity']
            orderitems.append(
                OrderItem(order=order, product=i, quantity=q, total=q*i.price))
        OrderItem.objects.bulk_create(orderitems)
        cart.clear()
        messages.success(self.request, 'Your order is successfully placed.')
        return redirect('store:product_list')


class MyOrders(LoginRequiredMixin, generic.ListView):
    model = Order
    template_name = 'orders/order_list.html'
    context_object_name = 'orders'
    paginate_by = 20

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user).annotate(total_items=Count('items'))


class OrderDetails(LoginRequiredMixin, generic.DetailView):
    model = Order
    context_object_name = 'order'
    template_name = 'orders/order_details.html'

    def get_queryset(self, **kwargs):
        objs = super().get_queryset(**kwargs)
        return objs.filter(user=self.request.user).prefetch_related('items', 'items__product')


class OrderInvoice(LoginRequiredMixin, generic.DetailView):
    model = Order
    context_object_name = 'order'
    template_name = 'orders/order_invoice.html'

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.prefetch_related('items', 'items__product')

    def get_object(self, **kwargs):
        obj = super().get_object(**kwargs)
        if obj.user_id == self.request.user.id or self.request.user.is_superuser:
            return obj
        raise Http404

def allorders(request):
    orders = Order.objects.all()
    #Totalorders = Order.objects.count()Cancelled Packed
    Totalorders=orders.count()
    pending=orders.filter(status='Pending').count()
    Cancelled=orders.filter(status='Cancelled').count()
    Packed=orders.filter(status='Packed').count()
    shippedandPacked=orders.filter(status='Shipped').count()
    delivered=orders.filter(status="Delivered").count()
    context = {
        'orders':orders,
        'Totalorders':Totalorders,
        'orders_pending':pending,
        'shippedandPacked':shippedandPacked,
        'orders_delivered':delivered,
        'Cancelled':Cancelled,
        'Packed':Packed,
        }

    return  render(request, 'orders/allorders.html',context)

def adminpageorders(request,pk):
    order = Order.objects.get(id=pk)
    return render(request, 'orders/adminpageorders.html',{'order':order})

class editorders(UpdateView):
    model = Order
    template_name = 'orders/editorders.html'
    fields =[
        'address', 
        'city', 
        'street_name',
        'district_name',
        'ward_name',
        'country_name',
        'phoneNo', 
        'paid',
        'status',
        ]
    success_url=reverse_lazy('orders:allorders')

def allproducts(request):
    allproducts =Product.objects.all()
    productcount=allproducts.count()
    context ={
        'allproducts': allproducts,
        'productcount':productcount
    }
    return render(request, 'orders/allproducts.html',context)

def buyandsell(request):
    return render(request, 'orders/buyandsell.html')


def allusers(request):
    allusers =User.objects.all()
    usercount = allusers.count()
    context = {
        'allusers':allusers,
        'usercount':usercount,
    }
    return render(request, 'orders/allusers.html',context)


class editUser(UpdateView):
    model = User
    template_name = 'orders/editUser.html'
    fields =  [
        'email',
        'first_name', 
        'last_name', 
        'username',
        'is_staff',
        'is_active',
        ]
    success_url=reverse_lazy('orders:allusers')

def remouser(request, pk):
    remouser =get_object_or_404(User,id=pk)
    if request.method == 'POST':
        remouser.delete() 
        messages.success(request,"User is deleted Successfully")
        return redirect('orders:allusers')
    return render(request,'orders/remouser.html',{'remouser' : remouser}) 