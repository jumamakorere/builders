from django.db import models
from django.conf import settings
from store.models import Product
from django.shortcuts import reverse
from django.contrib.auth.models import User
from django_countries.fields import CountryField
from django.core.validators import RegexValidator
from phonenumber_field.modelfields import PhoneNumberField

# Create your models here.
#PHONE_NUMBER_REGEX = RegexValidator(r'^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$', 'only valid Phone number is required')
choices = (
    ('Pending', 'Pending'),
    ('Cancelled', 'Cancelled'),
    ('Packed', 'Packed'),
    ('Shipped', 'Shipped'),
    ('Delivered', 'Delivered'),
)


class Order(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             related_name='orders', on_delete=models.CASCADE)
    address = models.CharField(max_length=150, blank=False, null=False)
    city = models.CharField(max_length=200,blank=True, null=True)
    street_name = models.CharField(max_length=200,blank=True, null=True)
    district_name = models.CharField(max_length=200,blank=True, null=True)
    ward_name = models.CharField(max_length=200,blank=True, null=True)
    #country_name = models.CharField(max_length=200,blank=True, null=True)
    country_name = CountryField(blank_label='(select country)')
    #phoneNo = models.IntegerField(max_length=14, validators=[PHONE_NUMBER_REGEX])
    phone_regex = RegexValidator(regex=r'^(\+\d{1,3})?,?\s?\d{8,13}', message="Phone number must be entered in the format: '+255758038673'. Up to 15 digits allowed.")
    #phoneNo = models.IntegerField(validators=[phone_regex], max_length=17, blank=True) # validators should be a list
    phoneNo=PhoneNumberField(("Phone Number"),null=False, blank=False)
    phoneNo.error_messages['invalid'] = 'Incorrect International Calling Code or Mobile Number! correct by format: +255 XXX XXX XXX XXXX',
    paid = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    status = models.CharField(
        choices=choices, max_length=10, default='Pending')
    total_price = models.FloatField(null=False, blank=False)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return f'Order {self.id}'

    def get_absolute_url(self):
        return reverse('orders:invoice', kwargs={'pk': self.pk})


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(
        Product, related_name='ordered', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    total = models.FloatField(null=False, blank=False)

    def __str__(self):
        return f'Order Item {self.id}'

# class Messages(models.Model):
#     message = models.TextField()
#     title = models.CharField(max_length=20,blank=True, null=True)
#     user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
#     def __str__(self):
#         return self.message
#     class Meta:
#         verbose_name_plural = 'Messages'
       

