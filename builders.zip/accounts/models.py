from django.db import models
from django.contrib.auth.models import User

def user_directory_path(instance, filename):
    return 'users/avatars/{0}/{1}'.format(instance.user.id, filename)

from django.conf import settings
from django.contrib.auth.models import User 
User = settings.AUTH_USER_MODEL
# Create your models here.
# class Profile(models.Model):
#     user = models.OneToOneField(User,null=True,blank=True,on_delete=models.CASCADE)
#     Phone_number = models.CharField(max_length=20, null=True,blank=True)
#     city = models.CharField(max_length=200,blank=True, null=True)
#     street_name = models.CharField(max_length=200,blank=True, null=True)
#     district_name = models.CharField(max_length=200,blank=True, null=True)
#     ward_name = models.CharField(max_length=200,blank=True, null=True)
#     country_name = models.CharField(max_length=200,blank=True, null=True)
#     pin_code = models.CharField(max_length=10,blank=True, null=True)
#     created = models.DateTimeField(auto_now_add=True,blank=True, null=True)
#     profile_pic = models.ImageField(null=True,blank=True,upload_to="profiles/")
#     def __str__(self):
#         return str(self.user)

